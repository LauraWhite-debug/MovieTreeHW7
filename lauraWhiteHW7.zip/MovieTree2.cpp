#include <iostream>
#include <fstream>
#include "MovieTree2.hpp"

using namespace std;

LLMovieNode* getLLMovieNode(int r, std::string t, int y, float q)
{
	LLMovieNode* lmn =new LLMovieNode();
	lmn->ranking = r;
	lmn->title=t;
	lmn->year =y;
	lmn->rating =q;
	lmn->next =NULL;
	return lmn;
}

/* ------------------------------------------------------ */
MovieTree::MovieTree()
{
	root = NULL;
}
void _destructLL(LLMovieNode* head)
{
	LLMovieNode* current = head;
	LLMovieNode* temp = NULL;
	while(current != NULL)
	{
		temp = current->next;
		delete current;
		current = temp;
	}
}

void _destrucMovieTree(TreeNode* curr) 
{
	if(curr == NULL)
	{
		return;
	}
	else
	{
		_destrucMovieTree(curr->leftChild);
		_destrucMovieTree(curr->rightChild);
		_destructLL(curr->head);
		delete curr;
		curr = NULL;
	}
}
MovieTree::~MovieTree()
{
	_destrucMovieTree(root);
}
/* ------------------------------------------------------ */
void inorderTraversalHelper(TreeNode * root) 
{
	if (root == NULL)
	{
		return;
	}

	inorderTraversalHelper(root->leftChild);
	cout << root->titleChar << " ";
	inorderTraversalHelper(root->rightChild);
}

void MovieTree::inorderTraversal() {
	inorderTraversalHelper(root);
	cout << endl;
}

/* ------------------------------------------------------ */
TreeNode* searchCharHelper(TreeNode* curr, char key)
{
    if (curr == NULL)
        return curr;
    else if(curr->titleChar == key)
        return curr;
    else if (curr->titleChar > key)
        return searchCharHelper(curr->leftChild, key);
    else
        return searchCharHelper(curr->rightChild, key);
}

TreeNode* MovieTree::searchCharNode(char key)
{
    return searchCharHelper(root, key);
}

/* ------------------------------------------------------ */

void _showMovieCollection(TreeNode* n)
{
	if(n == NULL)
	{
		return;		
	}
	else
	{
		_showMovieCollection(n->leftChild);
		cout << "Movies starting with letter: " << n->titleChar << endl;
		// inorderTraversalHelper(n);
		LLMovieNode* currMovie = n->head;
		while(currMovie != NULL)
		{
			cout << " >> " << currMovie->title << " " << currMovie->rating << endl;
			currMovie = currMovie->next; 
		}
		_showMovieCollection(n->rightChild);
	
	}
}
void MovieTree::showMovieCollection()
{
	_showMovieCollection(root);
}


TreeNode* _insertMovie(TreeNode* &letterNode, TreeNode* newMovie)
{
   if (letterNode == NULL)
   {
       return newMovie;
   }

   if (newMovie->titleChar < letterNode->titleChar)
   {
       TreeNode* leftNode = _insertMovie(letterNode->leftChild, newMovie);
       letterNode->leftChild = leftNode;
       leftNode->parent = letterNode;
   }
   else if (newMovie->titleChar > letterNode->titleChar)
   {
       TreeNode* rightNode = _insertMovie(letterNode->rightChild, newMovie);
       letterNode->rightChild = rightNode;
       rightNode->parent = letterNode;
   }
   else if (newMovie->titleChar == letterNode->titleChar)
   {
       LLMovieNode* insertNode = newMovie->head;
       LLMovieNode* curr = letterNode->head;
       LLMovieNode* prev = NULL;
       while (curr != NULL && curr->title.compare(insertNode->title) < 0)
       {
           prev = curr;
           curr = curr->next;
       }

       if (curr != NULL && curr->title.compare(insertNode->title) == 0) {return letterNode;}
    
       else
       {
           if (prev == NULL)
           {
               insertNode->next = letterNode->head;
               letterNode->head = insertNode;
           }
           else if (curr == NULL) {prev->next = insertNode;}
           else
           {
               prev->next = insertNode;
               insertNode->next = curr;
           }
       }
   }

   return letterNode;
} 


void MovieTree::insertMovie(int ranking, std::string title, int year, float rating)
{
   LLMovieNode* addMovie = getLLMovieNode(ranking,  title,year, rating);
   TreeNode* newNode = new TreeNode;
   newNode->titleChar = title.at(0);
   newNode->head = addMovie;
   root = _insertMovie(root, newNode);
} 
TreeNode* _removeMovie(TreeNode* currCharNode, string title)
{
	if(currCharNode == NULL) // if at any point tree node for mtitle character not in tree 
	{
		cout << "Movie not found." << endl;
		return currCharNode;
	}
	else if(currCharNode->titleChar > title.at(0)) // if current character is greater than title character
	{
		currCharNode->leftChild = _removeMovie(currCharNode->leftChild, title); // call _removeMovie on left child 
	}
	else if(currCharNode->titleChar < title.at(0)) // if current character is less than title character
	{
		currCharNode->rightChild = _removeMovie(currCharNode->rightChild, title); // call function on right child
	}
	else if(currCharNode->titleChar == title.at(0)) // if they are equal
	{
		LLMovieNode* currMovieNode = currCharNode->head; // set currMovieNode to head of linked list
		LLMovieNode* prev = NULL;

		while(currMovieNode != NULL && currMovieNode->title.compare(title) < 0) // while not at end of list and current title is less than input title
		{
			prev = currMovieNode; // traverse linked list
			currMovieNode = currMovieNode->next;	
		}
		// exit loop when reach desired title
		if(prev == NULL) // if desire movie is head
		{
			if(currCharNode->head->next != NULL) // and if head is not the only node in list
			{
				currCharNode->head = currCharNode->head->next; // set head to head next in order to remove desire movie from list
				return currCharNode;
			}
			else
			{
				currCharNode->head = NULL;
				return currCharNode;
			}
		}
		if(prev != NULL) // if desired movie is not head
		{
			if(currMovieNode->next != NULL) // if desired movie is not last node in list
			{
				prev->next = currMovieNode->next; // point prev next to current next, thereby removing desired node 
				return currCharNode;
			}
			else
			{
				prev->next = NULL;
				return currCharNode;
			}
		}
	}
	return currCharNode;
}
void MovieTree::removeMovieRecord(string title)
{
	root = _removeMovie(root, title);
}

void MovieTree::leftRotation(TreeNode* curr)
{
	if(curr == NULL)
	{
		return;
	}
	TreeNode* rotateNode = curr->rightChild;
	if(root->titleChar == curr->titleChar) // left rotation at root
	{
		curr->rightChild = rotateNode->leftChild;
		rotateNode->leftChild = curr;
		rotateNode->parent = NULL;
		curr->parent = rotateNode;
		if(curr->rightChild != NULL)
		{
			curr->rightChild->parent = curr;
		}
		root = rotateNode;
		return;
	}
	if(curr->titleChar == curr->parent->rightChild->titleChar)
	{
		curr->parent->rightChild = rotateNode;
	}
	else
	{
		curr->parent->leftChild = rotateNode;
	}
	rotateNode->parent = curr->parent;
	curr->parent = rotateNode;
	curr->rightChild = rotateNode->leftChild;
	if(rotateNode->leftChild != NULL)
	{
		rotateNode->leftChild->parent = curr;
	}
    rotateNode->leftChild = curr;
}

